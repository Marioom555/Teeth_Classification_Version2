import os
from torchvision.datasets import ImageFolder
from torch.utils.data import Dataset
import albumentations as A
from albumentations.pytorch import ToTensorV2
import cv2
import numpy as np

def get_transforms(split='train', img_size=224):
    if split.lower() == 'train':
        return A.Compose([
            A.Resize(img_size, img_size),
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.3),
            A.RandomRotate90(p=0.3),
            A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1,
                               rotate_limit=15, p=0.5),
            A.OneOf([
                A.RandomBrightnessContrast(p=0.5),
                A.HueSaturationValue(p=0.5),
                A.CLAHE(p=0.3)
            ], p=0.7),
            A.GaussianBlur(p=0.2),
            A.Normalize(),
            ToTensorV2(),
        ])
    else:  # validation/test
        return A.Compose([
            A.Resize(img_size, img_size),
            A.Normalize(),
            ToTensorV2(),
        ])

class TeethDataset(Dataset):
    def __init__(self, root_dir, split='train', img_size=224):
        self.root = os.path.join(root_dir, split)
        if not os.path.exists(self.root):
            raise FileNotFoundError(f"Path does not exist: {self.root}")
        self.samples = ImageFolder(self.root)
        self.imgs = self.samples.imgs
        self.classes = self.samples.classes
        self.transform = get_transforms(split, img_size)

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        path, label = self.imgs[idx]
        img = cv2.imread(path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        augmented = self.transform(image=img)
        image = augmented['image']
        return image, label
