import torch, cv2, numpy as np, gradio as gr
from models import create_model
from albumentations import Compose, Resize, Normalize
from albumentations.pytorch import ToTensorV2

MODEL_NAME = "tf_efficientnet_b4_ns"
CHECKPOINT_PATH = "/content/runs/best.pth"
IMG_SIZE = 380
NUM_CLASSES = 7
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

CLASS_NAMES = [
    "Canker Sores (CaS) Disease ",
    "Cold Sores (CoS) Disease ",
    "Gangivostomatitis (Gum) Disease ",
    "Mouth Cancer (MC) mouth cancer (MC) Disease ",
    "Oral Cancer (OC) Disease ",
    "Oral Lichen Planus (OLP) Disease ",
    "Oral Thrush (OT) Disease "
]

def load_model():
    model = create_model(MODEL_NAME, num_classes=NUM_CLASSES, pretrained=False)
    chk = torch.load(CHECKPOINT_PATH, map_location=DEVICE)
    model.load_state_dict(chk["model_state"])
    model.to(DEVICE).eval()
    return model

model = load_model()
transform = Compose([Resize(IMG_SIZE, IMG_SIZE), Normalize(), ToTensorV2()])

def predict(image):
    image = np.array(image)
    tensor = transform(image=image)["image"].unsqueeze(0).to(DEVICE).float()
    with torch.no_grad():
        output = model(tensor)
        probs = output.softmax(dim=1)[0].cpu().numpy()
        pred_idx = int(probs.argmax())
        pred_class = CLASS_NAMES[pred_idx]
    return {cls: float(probs[i]) for i, cls in enumerate(CLASS_NAMES)}, pred_class

iface = gr.Interface(
    fn=predict,
    inputs=gr.Image(type="pil", label="Upload Disease Image"),
    outputs=[gr.Label(num_top_classes=7, label="Prediction Probabilities"),
             gr.Textbox(label="Predicted Class")],
    title="🦷 Teeth Classification Diseases ",
    description="Upload a dental Disease Image and let us classify possible dental issues."
)

if __name__ == "__main__":
    iface.launch(share=True)
