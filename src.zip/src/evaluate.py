import argparse, os
import torch
from torch.utils.data import DataLoader
from dataset import TeethDataset
from models import create_model
import torch.nn as nn
import numpy as np
from tqdm import tqdm

def evaluate(model, loader, criterion, device):
    model.eval()
    running_loss, all_preds, all_targets = 0.0, [], []
    with torch.no_grad():
        for imgs, labels in tqdm(loader, desc="Evaluating"):
            imgs, labels = imgs.to(device).float(), labels.to(device)
            out = model(imgs)
            loss = criterion(out, labels)
            running_loss += loss.item() * imgs.size(0)
            preds = out.argmax(dim=1).detach().cpu().numpy()
            all_preds.extend(preds.tolist())
            all_targets.extend(labels.detach().cpu().numpy().tolist())
    epoch_loss = running_loss / len(loader.dataset)
    acc = (np.array(all_preds) == np.array(all_targets)).mean()
    return epoch_loss, acc

def main():
    parser = argparse.ArgumentParser(description="Evaluate trained model")
    parser.add_argument("--data_dir", required=True, help="Parent dataset dir (with 'data/val')")
    parser.add_argument("--model_path", default="/content/runs/best.pth")
    parser.add_argument("--model", default="tf_efficientnet_b4_ns")
    parser.add_argument("--num_classes", type=int, default=7)
    parser.add_argument("--img_size", type=int, default=380)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)
    val_ds = TeethDataset(os.path.join(args.data_dir, "data"), "val", img_size=args.img_size)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=2)

    if not os.path.exists(args.model_path):
        raise FileNotFoundError(f"❌ Model checkpoint not found at {args.model_path}")

    model = create_model(args.model, num_classes=args.num_classes, pretrained=False).to(device)
    checkpoint = torch.load(args.model_path, map_location=device)
    model.load_state_dict(checkpoint["model_state"])

    criterion = nn.CrossEntropyLoss()
    val_loss, val_acc = evaluate(model, val_loader, criterion, device)
    print(f"✅ Validation Loss: {val_loss:.4f} | Validation Accuracy: {val_acc:.4f}")

if __name__ == "__main__":
    main()
