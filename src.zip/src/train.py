import argparse, os, time
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from dataset import TeethDataset
from models import create_model
from utils import save_checkpoint
from tqdm import tqdm
import numpy as np

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss, all_preds, all_targets = 0.0, [], []
    for imgs, labels in tqdm(loader, desc="Training"):
        imgs, labels = imgs.to(device).float(), labels.to(device)
        optimizer.zero_grad()
        out = model(imgs)
        loss = criterion(out, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * imgs.size(0)
        preds = out.argmax(dim=1).detach().cpu().numpy()
        all_preds.extend(preds.tolist())
        all_targets.extend(labels.detach().cpu().numpy().tolist())
    epoch_loss = running_loss / len(loader.dataset)
    acc = (np.array(all_preds) == np.array(all_targets)).mean()
    return epoch_loss, acc

def validate(model, loader, criterion, device):
    model.eval()
    running_loss, all_preds, all_targets = 0.0, [], []
    with torch.no_grad():
        for imgs, labels in tqdm(loader, desc="Validation"):
            imgs, labels = imgs.to(device).float(), labels.to(device)
            out = model(imgs)
            loss = criterion(out, labels)
            running_loss += loss.item() * imgs.size(0)
            preds = out.argmax(dim=1).detach().cpu().numpy()
            all_preds.extend(preds.tolist())
            all_targets.extend(labels.detach().cpu().numpy().tolist())
    epoch_loss = running_loss / len(loader.dataset)
    acc = (np.array(all_preds) == np.array(all_targets)).mean()
    return epoch_loss, acc

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", required=True,
                        help="Parent dataset dir (containing 'data/train', 'data/val', 'data/test')")
    parser.add_argument("--model", default="tf_efficientnet_b4_ns")
    parser.add_argument("--img-size", type=int, default=380)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--num-classes", type=int, default=7)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)
    train_ds = TeethDataset(os.path.join(args.data_dir, "data"), "train", img_size=args.img_size)
    val_ds = TeethDataset(os.path.join(args.data_dir, "data"), "val", img_size=args.img_size)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=2)

    model = create_model(args.model, num_classes=args.num_classes, pretrained=True).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=args.lr)

    best_val = 0.0
    os.makedirs("runs", exist_ok=True)
    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc = validate(model, val_loader, criterion, device)
        print(f"Epoch {epoch}/{args.epochs} | train_loss={train_loss:.4f} acc={train_acc:.4f} "
              f"| val_loss={val_loss:.4f} acc={val_acc:.4f} | time={(time.time()-t0):.1f}s")

        save_checkpoint({"model_state": model.state_dict(),
                         "optim_state": optimizer.state_dict(),
                         "epoch": epoch},
                        f"runs/epoch_{epoch}.pth")
        if val_acc > best_val:
            best_val = val_acc
            save_checkpoint({"model_state": model.state_dict(),
                             "optim_state": optimizer.state_dict(),
                             "epoch": epoch},
                            "runs/best.pth")

if __name__ == "__main__":
    main()
