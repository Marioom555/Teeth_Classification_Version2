
import timm
import torch.nn as nn

def create_model(model_name='tf_efficientnet_b4_ns', num_classes=7, pretrained=True):
    # generic factory using timm
    model = timm.create_model(model_name, pretrained=pretrained, num_classes=num_classes)
    return model
