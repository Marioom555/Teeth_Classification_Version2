
import torch
import os
import numpy as np
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt

def save_checkpoint(state, fname='runs/last.pth'):
    os.makedirs(os.path.dirname(fname), exist_ok=True)
    torch.save(state, fname)

def load_checkpoint(fname, model, optimizer=None):
    chk = torch.load(fname, map_location='cpu')
    model.load_state_dict(chk['model_state'])
    if optimizer and 'optim_state' in chk:
        optimizer.load_state_dict(chk['optim_state'])
    return chk.get('epoch', -1)

def compute_metrics(y_true, y_pred, target_names=None):
    acc = accuracy_score(y_true, y_pred)
    report = classification_report(y_true, y_pred, target_names=target_names, digits=4)
    cm = confusion_matrix(y_true, y_pred)
    return acc, report, cm

def plot_confusion(cm, classes, out_path='runs/confusion.png'):
    plt.figure(figsize=(8,6))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion matrix')
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    plt.savefig(out_path)
    plt.close()
