
import argparse, torch, cv2, numpy as np
from models import create_model
from albumentations import Compose, Resize, Normalize
from albumentations.pytorch import ToTensorV2

def load_image(path, img_size=380):
    img = cv2.imread(path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    aug = Compose([Resize(img_size, img_size), Normalize(), ToTensorV2()])
    out = aug(image=img)['image'].unsqueeze(0)
    return out

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', required=True)
    parser.add_argument('--image', required=True)
    parser.add_argument('--model', default='tf_efficientnet_b4_ns')
    parser.add_argument('--img-size', type=int, default=380)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    device = torch.device(args.device)
    model = create_model(args.model, num_classes=7, pretrained=False)
    chk = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(chk['model_state'])
    model.to(device).eval()
    img = load_image(args.image, args.img_size).to(device).float()
    with torch.no_grad():
        out = model(img)
        pred = out.argmax(dim=1).item()
    print('Predicted class index:', pred)

if __name__=='__main__':
    main()
